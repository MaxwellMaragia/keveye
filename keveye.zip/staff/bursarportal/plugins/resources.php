<link rel="shortcut icon" type="image/png" href="../assets/images/keveye_logo.png"/>
<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700" rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="http://netdna.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<link rel="stylesheet" href="../assets/bootstrap/css/bootstrap.css"/>
<link rel="stylesheet" href="../assets/css/admin.css"/>
<link rel="stylesheet" href="../assets/css/responsive.css"/>
<link rel="stylesheet" href="../assets/css/font-awesome.css"/>
<link rel="stylesheet" href="../assets/css/dataTables.bootstrap.css"/>

<link rel="stylesheet" href="../bootstrap/css/bootstrap.css"/>