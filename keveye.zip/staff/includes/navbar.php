<!-- Header -->


<!-- Header -->

<header class="header d-flex flex-row" >
    <div class="header_content d-flex flex-row align-items-center">
        <!-- Logo -->
        <div class="logo_container">
            <div class="logo">
                <img src="../images/keveye_logo.png" alt="" style="width:50px ">

            </div>

        </div>
        <h3 style="color:#8C4200;">Keveye Girls School</h3>
        <!-- Main Navigation -->
        <nav class="main_nav_container">
            <div class="main_nav">
                <ul class="main_nav_list">
                    <li class="main_nav_item"><a href="../index.php">Home</a></li>

                </ul>

            </div>
        </nav>
    </div>
    <div class="header_side d-flex flex-row justify-content-center align-items-center" style="background-color: #8C4200">
        <span class="fa fa-phone" style="color:white;"></span>
        <span style="color:white;">+254 712 599 273</span>
    </div>

    <!-- Hamburger -->
    <div class="hamburger_container">
        <i class="fas fa-bars trans_200"></i>
    </div>

</header>

<!-- Menu -->
<div class="menu_container menu_mm">

    <!-- Menu Close Button -->
    <div class="menu_close_container">
        <div class="menu_close"></div>
    </div>

    <!-- Menu Items -->
    <div class="menu_inner menu_mm">
        <div class="menu menu_mm">
            <ul class="menu_list menu_mm">
                <li class="menu_item menu_mm"><a href="../index.php" style="text-transform: ">Home</a></li>
            </ul>



            <div class="menu_copyright menu_mm"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
                <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></div>
        </div>

    </div>

</div>