<footer class="footer" style="background-color: black;position:relative;margin-top: 50px;">
    <div class="container">

        <!-- Newsletter -->



        <!-- Footer Content -->

        <div class="footer_content">
            <div class="row">

                <!-- Footer Column - About -->
                <div class="col-lg-3 footer_col">


                    <p class="footer_about_text"><h2 style="color:#8B4513;">Keveye Girls High School</h2></p>

                </div>

                <!-- Footer Column - Menu -->

                <div class="col-lg-3 footer_col">
                    <div class="footer_column_title" style="color:#8B4513;">Menu</div>
                    <div class="footer_column_content">
                        <ul>
                            <li class="footer_list_item"><a href="index.php">Home</a></li>
                            <!--<li class="footer_list_item"><a href="about.php">About Us</a></li>-->
                            <li class="footer_list_item"><a href="gallery.php">Gallery</a></li>
                            <li class="footer_list_item"><a href="news.php">News</a></li>
                            <li class="footer_list_item"><a href="contact.php">Contact</a></li>
                        </ul>
                    </div>
                </div>

                <!-- Footer Column - Usefull Links -->

                <div class="col-lg-3 footer_col">
                    <div class="footer_column_title" style="color:#8B4513;">Useful Links</div>
                    <div class="footer_column_content">
                        <ul>
                            <li class="footer_list_item"><a href="portal/student_login.php">Students' portal</a></li>
                            <li class="footer_list_item"><a href="portal/teacher_login.php">Teacher's portal</a></li>
                            <li class="footer_list_item"><a href="portal/parent_login.php">Parents' portal</a></li>

                        </ul>
                    </div>
                </div>

                <!-- Footer Column - Contact -->

                <div class="col-lg-3 footer_col">
                    <div class="footer_column_title" style="color:#8B4513;">Contact</div>
                    <div class="footer_column_content">
                        <ul>
                            <li class="footer_contact_item">
                                <div class="footer_contact_icon">
                                    <span class="fa fa-location-arrow" style="color:#8B4513;"></span>
                                </div>
                                Vihiga county
                            </li>
                            <li class="footer_contact_item">
                                <div class="footer_contact_icon">
                                    <span class="fa fa-phone" style="color: #8B4513;"></span>
                                </div>
                                +254 712 599273
                            </li>
                            <li class="footer_contact_item">
                                <div class="footer_contact_icon">
                                    <span class="fa fa-envelope" style="color: #8B4513;"></span>
                                </div>keveyegirls@yahoo.com
                            </li>
                        </ul>
                    </div>
                </div>

            </div>
        </div>

        <!-- Footer Copyright -->

        <div class="footer_bar d-flex flex-column flex-sm-row align-items-center">
            <div class="footer_copyright">
                    <span>
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | codei</a>
                        <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></span>
            </div>
            <div class="footer_social ml-sm-auto">
                <ul class="menu_social">
                    <li class="menu_social_item"><a href="#"><i class="fab fa-pinterest"></i></a></li>
                    <li class="menu_social_item"><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                    <li class="menu_social_item"><a href="#"><i class="fab fa-instagram"></i></a></li>
                    <li class="menu_social_item"><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                    <li class="menu_social_item"><a href="#"><i class="fab fa-twitter"></i></a></li>
                </ul>
            </div>
        </div>

    </div>
</footer>