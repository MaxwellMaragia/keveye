<div id="wrapper">
    <nav class="navbar navbar-default top-navbar" role="navigation">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="#">LIBRARIAN</a>
        </div>

        <ul class="nav navbar-top-links navbar-right">

            </li>
            <!-- /.dropdown -->
        </ul>
    </nav>
    <!--/. NAV TOP  -->
    <nav class="navbar-default navbar-side" role="navigation">
        <div class="sidebar-collapse">
            <ul class="nav" id="main-menu">

                <li>
                    <a class="active-menu" href="index.php"><i class="fa fa-dashboard"></i> Dashboard</a>
                </li>
                <li>
                    <a href="addbooks.php"><i class="fa fa-book"></i>Add books</a>
                </li>
                <li>
                    <a href="lendbooks.php"><i class="fa fa-arrow-circle-right"></i>lend books</a>
                </li>
                <!-- -->
                <!-- -->
                <li>
                    <a href="lendlist.php"><i class="fa fa-trash-o"></i>Clear students</a>
                </li>
                <!-- -->
                <li>
                    <a href="logs.php"><i class="fa fa-history"></i>Activity logs</a>
                </li>


                <!-- -->
                <li>
                    <a href="#"><i class="fa fa-user"></i>Manage profile<span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level">
                        <li>
                            <a href="changepassword.php">Change password</a>
                        </li>
                        <li>
                            <a href="logout.php">logout</a>
                        </li>

                    </ul>
                </li>
                <!-- -->




            </ul>
            </ul>

        </div>

    </nav>
    <!-- /. NAV SIDE  -->