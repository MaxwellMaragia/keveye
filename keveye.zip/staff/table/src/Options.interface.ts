/** Plugin Options */
interface Options {
    columnSelector: string,
    sort: boolean,
    search: boolean
}

