<?php
/**
 * Redirect to homepage
 */

  header('location:../dashboard.php');