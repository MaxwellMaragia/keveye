<script type="text/javascript" src="../assets/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="../assets/js/buttons.flash.min.js"></script>
<script type="text/javascript" src="../assets/js/jszip.min.js"></script>
<script type="text/javascript" src="../assets/js/pdfmake.min.js"></script>
<script type="text/javascript" src="../assets/js/buttons.html5.min.js"></script>
<script type="text/javascript" src="../assets/js/buttons.print.min.js"></script>
