<script src="../assets/js/jquery-UI.js"></script>
<script src="../assets/bootstrap/js/bootstrap.js"></script>
<script src="../assets/js/jquery.metisMenu.js"></script>
<script src="../assets/js/custom.js"></script>
<script src="../assets/js/jquery.dataTables.js"></script>
<script src="../assets/js/dataTables.bootstrap.js"></script>

