<link rel="stylesheet" href="styles/bootstrap4/bootstrap.min.css">
<script src="js/jquery-3.2.1.min.js"></script>

<!--pagination-->
<script src="pagination/scripts/jquery.js"></script>
<script src="pagination/scripts/jquery-ui.js"></script>
<script src="pagination/scripts/jquery.table.hpaging.min.js"></script>
<!--pagination-->


<!--filter-->
<script src="table/dist/jquery.js"></script>
<script src="table/dist/excel-bootstrap-table-filter-bundle.js"></script>
<link rel="stylesheet" href="table/dist/excel-bootstrap-table-filter-style.css">
<!--filter-->


